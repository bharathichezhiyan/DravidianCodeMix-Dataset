 


# In[ ]:



# In[ ]:


from sklearn.utils import resample
import numpy as np
from numpy import array


# In[ ]:



f=open('kannada_offensive.csv','r')
lines = f.read()
lines = lines.split('\n')[:-1]


X = []
Y = []
data = []


for i in range(len(lines)):
 line = lines[i].split('\t')
#     data.append(a)
 if len(line[0])>0:
   X.append(line[1])
   Y.append(line[0])
Y = np.asarray(Y)
X = np.asarray(X)


# In[ ]:


# import pandas as pd
# df = pd.DataFrame(data, columns = ['labels', 'Sentences']) 


# In[ ]:


from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split( X, Y, test_size=0.1, random_state=5)


# In[ ]:


X_train, X_dev, Y_train, Y_dev = train_test_split( X_train, Y_train, test_size=0.111, random_state=5)


# In[ ]:


X_train_csv = []
for x in range(len(X_train)):
    line = []
    line.append(X_train[x])
    line.append(Y_train[x])
    X_train_csv.append(line)
    

out = open('kan_full_offensive_train.csv', 'w')
for row in X_train_csv:
    for column in row:
        out.write('%s\t' % column)
    out.write('\n')
out.close()


# In[ ]:


X_test_csv = []
for x in range(len(X_test)):
    line = []
    line.append(X_test[x])
    line.append(Y_test[x])
    X_test_csv.append(line)
    

out = open('kan_full_offensive_test.csv', 'w')
for row in X_test_csv:
    for column in row:
        out.write('%s\t' % column)
    out.write('\n')
out.close()


# In[ ]:


X_dev_csv = []
for x in range(len(X_dev)):
    line = []
    line.append(X_dev[x])
    line.append(Y_dev[x])
    X_dev_csv.append(line)
    

out = open('kan_full_offensive_dev.csv', 'w')
for row in X_dev_csv:
    for column in row:
        out.write('%s\t' % column)
    out.write('\n')
out.close()


